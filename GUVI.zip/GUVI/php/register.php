<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mydatabase";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];
    $r_password = $_POST["r_password"];

    $check_username_sql = "SELECT * FROM user WHERE username = '$username'";
    $check_username_result = $conn->query($check_username_sql);

    if ($check_username_result->num_rows > 0) {
        echo 'Username is already taken. Please choose another username'; 
        exit();
    }
    

    $uppercase = preg_match('@[A-Z]@', $password);
    $lowercase = preg_match('@[a-z]@', $password);
    $number = preg_match('@[0-9]@', $password);
    $specialChars = preg_match('@[^\w]@', $password);

    if (!$uppercase || !$lowercase || !$number || !$specialChars || strlen($password) < 8) {
        echo 'Password must be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, one number, and one special character';       
        exit();
    }
    else{
        $sql = "INSERT INTO user (username, password) VALUES ('$username', '$password')";

    }


    if ($conn->query($sql) === TRUE) {
        echo "Success";
        exit();
        
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
